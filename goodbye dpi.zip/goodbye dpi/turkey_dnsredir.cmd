@echo off
chcp 65001 >nul
cd /d "%~dp0"

>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    goto UACPrompt
) else ( goto GotAdmin )

:UACPrompt
echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
"%temp%\getadmin.vbs"
del "%temp%\getadmin.vbs"
exit /B

:GotAdmin
cd /d "%~dp0"

cls
echo ========================================================
echo   GoodbyePingDPI - Ultimate Ping Destroyer v7
echo ========================================================
echo 1 - Normal Ultra-Low Latency Mode
echo 2 - Assisted Hardware Ping Mode (CPU + GPU + RAM + 20 Pro Fix)
echo ========================================================
set /p "secim=Mod seciminizi yapin (1 veya 2): "

if "%secim%"=="2" goto HardwareMode
goto NormalMode

:HardwareMode
echo.
echo [!] Hardware ve Tum Ping Dusurucu Fixler Aktif Ediliyor...

:: 1. GPU ve CPU Oncelik Ayarlari
reg add "HKCU\Software\Microsoft\DirectX\UserGpuPreferences" /v "DirectXUserGlobalSettings" /t REG_SZ /d "PerfFlags=0x00000002;" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\RobloxPlayerBeta.exe\PerfOptions" /v "CpuPriorityClass" /t REG_DWORD /d 4 /f >nul 2>&1

:: 17. Game DVR ve Arka Plan Kayitlarini Kapatma
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v "AllowGameDVR" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d 0 /f >nul 2>&1

:: 6. UDP Arabellek Boyutunu Sabitleme
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Afd\Parameters" /v "DefaultReceiveWindow" /t REG_DWORD /d 65536 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Afd\Parameters" /v "DefaultSendWindow" /t REG_DWORD /d 65536 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Afd\Parameters" /v "FastSendDatagramThreshold" /t REG_DWORD /d 1500 /f >nul 2>&1

:: 7, 8, 9. Arka Plan Hizmetlerini Durdurma (DoSvc, BITS, SysMain)
net stop DoSvc >nul 2>&1
net stop BITS >nul 2>&1
net stop SysMain >nul 2>&1
goto ApplyOptimizations

:NormalMode
echo.
echo [!] Normal mode aktif ediliyor...
goto ApplyOptimizations

:ApplyOptimizations
:: 12. Windows Ag Kisitlama Sinirini Kaldirma
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NetworkThrottlingIndex" /t REG_DWORD /d 4294967295 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d 0 /f >nul 2>&1

:: 5. DNS Onbellek Sifirlama ve Sikiştirma
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" /v "MaxCacheTtl" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" /v "MaxNegativeCacheTtl" /t REG_DWORD /d 0 /f >nul 2>&1

:: 20. Komşu Önbellek Limiti Artırma (Neighbor Cache Limit)
netsh int ip set global neighborcachelimit=4096 >nul 2>&1

:: 13, 11, 3, 4, 18 vb. Ag Yigini ve TCP/IP Optimizasyonlari
netsh int ip set global taskoffload=enabled >nul 2>&1
netsh int tcp set global autotuninglevel=normal >nul 2>&1
netsh int tcp set global ecncapability=disabled >nul 2>&1
netsh int tcp set global timestamps=disabled >nul 2>&1
netsh int tcp set global rss=enabled >nul 2>&1
netsh int tcp set global chimney=enabled >nul 2>&1
netsh int tcp set global nonsackrttresiliency=disabled >nul 2>&1
netsh int tcp set global initialRto=2000 >nul 2>&1
netsh int tcp set global hystart=disabled >nul 2>&1
netsh int tcp set global pacingprofile=off >nul 2>&1

:: 11. BBR Sikişma Kontrol Algoritmasi
netsh int tcp set supplemental template=internet congestionprovider=bbr >nul 2>&1
ipconfig /flushdns >nul 2>&1

:: 10. Ag Yolu Onceligi (QoS / DSCP Etiketleme)
powershell -Command "Remove-NetQosPolicy -Name 'RobloxPriority' -Confirm:$false -ErrorAction SilentlyContinue; New-NetQosPolicy -Name 'RobloxPriority' -AppPathName 'RobloxPlayerBeta.exe' -ThrottleRateAction None -NetworkProfile All -IPPrecedence 5 -ErrorAction SilentlyContinue" >nul 2>&1

:: 1, 2, 3, 4, 16, 18. PowerShell ile Ag Karti Gu tasarrufu, RSS, Checksum ve Interrupt Moderation Ayarlari
powershell -Command "$adapter = Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | Select-Object -First 1; if ($adapter) { Set-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName 'Energy Efficient Ethernet' -DisplayValue 'Disabled' -ErrorAction SilentlyContinue; Set-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName 'Green Ethernet' -DisplayValue 'Disabled' -ErrorAction SilentlyContinue; Set-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName 'Interrupt Moderation' -DisplayValue 'Disabled' -ErrorAction SilentlyContinue; Set-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName 'Receive Side Scaling' -DisplayValue 'Enabled' -ErrorAction SilentlyContinue }" >nul 2>&1

:: 14. 1ms Hiper Zamanlayici
powershell -Command "$code = '[DllImport(\"ntdll.dll\")] public static extern int NtSetTimerResolution(uint DesiredResolution, bool SetResolution, out uint CurrentResolution);'; Add-Type -MemberDefinition $code -Name 'Timer' -Namespace 'Nt'; [Nt.Timer]::NtSetTimerResolution(10000, $true, [ref]$null)" >nul 2>&1

:: 15. GoodbyeDPI Sadece Roblox / Ag Baslatma
if exist "x86_64\goodbyedpi.exe" (
    cd /d "x86_64"
    start "" /realtime goodbyedpi.exe -5 --dns-addr 1.1.1.1 --dns-port 53 --dnsv6-addr 2606:4700:4700::1111 --dnsv6-port 53
) else if exist "x86\goodbyedpi.exe" (
    cd /d "x86"
    start "" /realtime goodbyedpi.exe -5 --dns-addr 1.1.1.1 --dns-port 53 --dnsv6-addr 2606:4700:4700::1111 --dnsv6-port 53
) else (
    start "" /realtime goodbyedpi.exe -5 --dns-addr 1.1.1.1 --dns-port 53 --dnsv6-addr 2606:4700:4700::1111 --dnsv6-port 53
)

cd /d "%~dp0"

echo.
echo [!] Tum 20 kritik ag ve donanim optimizasyonu basariyla uygulandi!
echo [!] Roblox oyuna girmeniz bekleniyor...

:: 19. Islemci RealTime Oncelik Sabitleme Dongusu
:MonitorLoop
timeout /t 3 /nobreak >nul
powershell -Command "$p = Get-Process -Name 'RobloxPlayerBeta' -ErrorAction SilentlyContinue; if ($p -and $p.PriorityClass -ne 'RealTime') { $p.PriorityClass = 'RealTime'; Write-Host '[!] Roblox RealTime oncelige kilitlendi!' }" >nul 2>&1
goto MonitorLoop